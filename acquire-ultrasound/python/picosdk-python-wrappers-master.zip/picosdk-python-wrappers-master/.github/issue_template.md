### Setup

* Example filename:
* Version of Python:
* Pico Technology device model:
* Driver name, version number and platform (32- or 64-bit):
* Operating system:
* USB port type	(e.g. 2.0):

### Description

#### Steps to reproduce the issue

Use one of two methods to describe the issue:

1. A list of steps to reproduce the issue. 
1. A natural language description of what you were doing when the issue occurred if you are unable to work out what the steps are. 

#### Actual Result



#### Expected Result



### Notes

Include any other information here.